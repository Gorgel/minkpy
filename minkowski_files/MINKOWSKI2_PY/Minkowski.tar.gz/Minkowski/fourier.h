extern void convolution(float*,parlist*);
extern void randomfield(float*,parlist*);
extern void gaussiankernel(float*, parlist*);
extern void normalize(float*,parlist*);
extern void fourn(float*,int*,int,int);
extern int idx(int,int,int,int*);
