/* Declarations */
extern void picture(int,FILE*,float*,parlist*);

